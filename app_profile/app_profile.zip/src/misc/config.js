const config = {};

config.serverPath = 'http://192.168.0.29:3000/'
config.dbCollection = 'users'

export default config;