export const emptyTemplate2 = `<span>-</span>
    <span>-</span>
    <span>-</span>
    <span>-</span>`;

export const userTemplate2 = (user) => `<span>${user._id}</span>
    <span>${user.profile}</span>
    <span>${user.username}</span>
    <span>-</span>`